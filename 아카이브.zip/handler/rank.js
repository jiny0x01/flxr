function c_get_user_rank_first(regionID){
    // 지역 1등 반환
}
function b_get_user_rank_list(regionID){
    // 지역 랭킹 순위 반환
}
function b_get_user_rank_my(regionID){
    // 내 랭킹 반환
}

function c_mod_user_rank_comment(regionID){
    // 상태메시지 변경
}

