
function c_get_challenge_list_new(gps, callback){
    // gps에 해당하는 도전과제 반환
}                      

function b_get_challenge_summary(challengeID, callback){
    // challenge_id에 대한 요약 반환
}

function c_add_save_challenge(challengeID, callback){
    // 찜목록에 challenge_id 저장
}

function b_get_challenge_info(challengeID, callback){
    // challenge_id에 대한 도전과제 자세히보기
}

function b_get_challenge_review_list(challengeID, callback){
    // 도전과제 후기 정보 반환
}

function c_mod_user_challenge_status_off(challengeID, callback){
    // 도전과제 포기
}

function b_get_user_challenge_list(userID, callback){
    // 도전중인 목록 반환 
}
function b_get_user_challenge_require(challengeID, callback){
    // 조건 상태 반환
}
function c_mod_user_challenge_status_clear(challengeID, callback){
    // 사용자의 도전과제 수행 상태 변경
}

function b_get_save_challenge_list(userID, callback){
    // 찜 목록 반환    
}
function c_del_save_challenge(challengeID, callback){
    // 찜 삭제 
}
function c_mod_save_challenge_num(challengeID, callback){
    // 찜 순서 변경
}

function c_add_challenge_review(userID, challengeID, callback){
    // 리뷰 등록
}

function b_add_challenge(userID, callback){
    // 도전과제 등록
}
function c_add_challenge_require(challengeID, callback){
    // 도전과제 조건 등록
}
function c_add_challenge_img(challengeID, callback){
    // 조건 사진 등록
}